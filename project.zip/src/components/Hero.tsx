import { ArrowDown } from 'lucide-react';

const Hero = () => {
  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background with gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-white z-0" />
      
      {/* Content */}
      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8">
        <img
          src="/assets/images/IMG_1689.JPG"
          alt="Profile"
          className="w-48 h-48 rounded-full mx-auto mb-8 object-cover border-4 border-white shadow-lg"
        />
        <h1 className="text-5xl font-bold text-gray-900 mb-4">Dava Yuste</h1>
        <p className="text-2xl text-gray-600 mb-8">Network Engineer | DevOps | Web Developer</p>
        <p className="max-w-2xl mx-auto text-gray-600 mb-12">
          Building scalable infrastructure and creating seamless web experiences. 
          Passionate about DevOps culture and modern web technologies.
        </p>
        <a
          href="#about"
          className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors"
        >
          Learn More
          <ArrowDown className="w-4 h-4" />
        </a>
      </div>

      {/* Decorative circles */}
      <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob" />
      <div className="absolute top-1/3 right-1/4 w-64 h-64 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000" />
      <div className="absolute bottom-1/4 left-1/2 w-64 h-64 bg-pink-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000" />
    </section>
  );
};

export default Hero;